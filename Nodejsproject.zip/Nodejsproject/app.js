const Express = require("express");
const path = require('path');
const Handlebars = require('handlebars');
const exhbs = require('express-handlebars');
const {allowInsecurePrototypeAccess} = require('@handlebars/allow-prototype-access');
const Mongoose = require("mongoose");

const BodyParser = require("body-parser");
//const DatabaseName;
var collection;

var app = Express();

app.use(BodyParser.urlencoded({
    extended: true
}));
app.use(BodyParser.json());
app.set('views', path.join(__dirname, '/views/'));
app.engine('hbs', exhbs({ handlebars: allowInsecurePrototypeAccess(Handlebars),extname: 'hbs', defaultLayout: 'mainLayout', layoutsDir: __dirname + '/views/layouts/' }));
app.set('view engine', 'hbs');
// const productRoutes = require('./routes/products');

// Middlewares

// app.use('/posts',() => {
//     console.log('This is middleware running');
// });

// Routes

app.get('/', (req, res) => {
    res.send('We are on Home');
});

// app.get('/posts',(req,res) => {
//     res.send('We are on Post');
// });

// Mongoose.connect('mongodb+srv://sivamdb_1:Shiv1234@cluster0-kpmae.mongodb.net/test?retryWrites=true&w=majority', {useNewUrlParser:true}, () => console.log('Connected'));
//  Mongoose.connect('mongodb+srv://sivamdb_1:Shiv1234@cluster0-kpmae.mongodb.net/test?retryWrites=true&w=majority:27017/jonesdb', {useNewUrlParser:true}, () => {
//     console.log('Connected')
// });

require('./models/user');

console.log('added user');
require('./models/product');


Mongoose.connect('mongodb://localhost:27017/dowjonesdb', { useNewUrlParser: true }, (err) => {
    if (!err) {
        console.log('Successfully Established Connection with MongoDB')
    }
    else {
        console.log('Failed to Establish Connection with MongoDB with Error: ' + err)
    }
});




// Mongoose.connect('mongodb://localhost:27017/jonesdb')
//   .then(() => console.log('MongoDB connected…'))
//   .catch(err => console.log(err))

// Mongoose.connect("mongodb://localhost:5000/jonesdb", (err) => {

// if(!err) {
//     console.log("You are connected!");
//   };

//  });

const userController = require('./controllers/userController');

app.listen(3005);

app.use('/user', userController);

// app.use(BodyParser.json());
// app.use(BodyParser.urlencoded({ extended: true }));

// var MongoClient = require('mongodb').MongoClient;
// // Connect to the db
// MongoClient.connect("mongodb://{user}:{password}@{host}:{port}/{database}", function(err, db) {

// if(!err) {
//     console.log("You are connected!");
//   };
// db.close();
// });


