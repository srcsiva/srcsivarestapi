const express = require('express');
var router = express.Router();
const Mongoose = require("mongoose");
const User = Mongoose.model('user');
var user = new User();

router.get('/',(req,res) => {
    res.render('user/addOrEdit',{viewTitle:"Insert User"})
});

router.post('/',(req,res) => {
    //console.log(req.body);
    if(req.body._id == '')
    {
        insertUser(req,res);
    }
    else
    {
        updateRecord(req,res);
    }
});

router.get('/list',(req,res) => {
    //res.json('from list');
    
    User.find((err,docs) => {
        if(!err)
        {
            res.render('user/list', {
                   list: docs 
            });
        }
        else
        {
            console.log('error in retrieving user list', + err);
        }
    });
});

router.get('/:id',(req,res) => {
    User.findById(req.params.id,(err,doc) => {
        if(!err)
        {
            res.render('user/addOrEdit',{
                  viewTitle: "Update User",
                  user: doc  
            });
        }
    });
});


function updateRecord(req,res)
{
    User.findOneAndUpdate({_id: req.body._id},req.body,{new:true},(err,doc) => {
        if(!err)
        {
            res.redirect('user/list');
        }
        else{
            if(err.name == 'ValidationError')
            {
                handleValidationError(err,req.body);
                res.render("user/addOrEdit",{
                    viewTitle: 'Update User',
                    user: req.body
                });
            }
            else
                console.log('error during record update' + err);
        }
    });
}

function insertUser(req,res) {
    // 

    user.name = req.body.name;
    user.email = req.body.email;

    user.save((err,doc) => {
        if(!err)
        {
            res.redirect('user/list');
        }
        else
        {
            if(err.name == 'ValidationError')
            {    
                handleValidationError(err,req.body);
                res.render("user/addOrEdit",{
                    viewTitle: "Insert User",
                    user: req.body                        
                });
            }
            else    
            console.log('Errror during insertion' + err);
        }
    });

    

    function handleValidationError(err,body)
    {
        for(field in err.errors)
        {
            switch(err.errors[field].path)
            {
                case 'name':
                    body['nameError'] =err.errors[field].message;
                    break;
                case 'email':
                    body['emailError']  = err.errors[field].message;
                    break;
                default:
                    break;    
            }
        }
    }
    
}

module.exports = router;