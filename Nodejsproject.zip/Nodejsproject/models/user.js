const mongoose = require('mongoose');

var userSchema = new mongoose.Schema({
    // _id: mongoose.Types.ObjectId,
    name: {
        type: String,
        required: 'name is required'
    },
    email: {
        type: String,
        required: 'email is required'
    }
});

userSchema.path('email').validate((val) => {
    emailRegex = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return emailRegex.test(val);
},'Invalid email');

//mongoose.model('user',userSchema);
var user = new mongoose.model('user', userSchema);

console.log('added');

//export default user;

module.exports = user;