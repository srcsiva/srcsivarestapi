const mongoose = require('mongoose');

const articleSchema = new mongoose.Schema({ 

  index: {
    type: Number, 
    required: [true, "Index is required"]
  },
  article_text: {
    type: String,
    required: [true, "Article Text is required"]
  },
  article_link: {
    type: String,
    required: [true, "Article Link can't be blank"]
  },
  article_date: {
    type: Date,
    required: [true, "Article Link can't be blank"]
  },
  journal_name: {
    type: String,
    required: [true, "Journal Name can't be blank"]
  },
  section_name: {
    type: String,
    required: [true, "Section Name can't be blank"]
  },
  page_view_count: {
    type: Number,
    required: [true, "Section Name can't be blank"]
  }

});

module.exports = mongoose.model('Article', articleSchema); 
